/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fees_management_system;

/**
 *
 * @author AAYUSH
 */
public class Fees_Management_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
